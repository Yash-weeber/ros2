^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robotiq_driver
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2023-07-17)
------------------
* Initial ROS 2 release of robotiq_driver
  * This package should be ignored by initial bloom release until serial or cxx_serial is released
  * includes support for Robotiq 2F 85
  * This package is not supported by Robotiq but is being maintained by PickNik Robotics
* Contributors: Alex Moriarty, Anthony Baker, Cory Crean, Erik Holum, Ezra Brooks, Marq Rasmussen, marqrazz
